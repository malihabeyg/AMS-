package EntityClasses;

public class Course {
    private int courseId;
    private String courseName;
    private int teachId;

    public Course(int courseId, String courseName, int teachId) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.teachId = teachId;
    }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public int getStdId(){ return teachId; }
    public void setStdId(int teachId){ this.teachId = teachId; }
    @Override
    public String toString() { return courseName; }
}

package EntityClasses;

public class Grade {
    private int submissionId;
    private String grade;
   
    public Grade(int submissionID, String grade) {
        this.submissionId = submissionID;
        this.grade = grade;
    }

    public int getSubmissionID() { return submissionId; }
    public void setSubmissionID(int submissionId) { this.submissionId = submissionId; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }
    @Override
    public String toString(){ return grade; }
}

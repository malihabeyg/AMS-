package EntityClasses;

import ManagementClasses.TeacherManagement;
import java.sql.SQLException;
import java.util.List;

public abstract class Teacher extends User {
    private List<Course> assignedCourses;
    
    public Teacher(){}
    public Teacher(int userId, String username, String password, String email, List<Course> assignedCourses) {
        super(userId, username, password, email);
        this.assignedCourses = assignedCourses;
    }
    
    public List<Course> getAssignedCourses() { return assignedCourses; }
    public void setAssignedCourses(List<Course> assignedCourses) { this.assignedCourses = assignedCourses; }
    
    public abstract void addTeacher(TeacherManagement newTeacher) throws SQLException;
    public abstract void updateTeacher(int userId, String newUsername, String newPassword, String newEmail) throws SQLException;
    public abstract void removeTeacher(int teacherId) throws SQLException;
    public abstract List<User> getTeachers() throws SQLException;
    public abstract int getTeacherIdByUserId(int userId) throws SQLException;
}
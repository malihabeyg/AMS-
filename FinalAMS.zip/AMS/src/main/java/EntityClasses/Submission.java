package EntityClasses;

public class Submission {
    private Integer submissionId;
    private int assignmentId;
    private int studentId;
    private String submissionDate;
    private String filePath;
    private String grade;

    public Submission(Integer submissionId, int assignmentId, int studentId, String submissionDate, String filePath, String grade) {
        this.submissionId = submissionId;
        this.assignmentId = assignmentId;
        this.studentId = studentId;
        this.submissionDate = submissionDate;
        this.filePath = filePath;
        this.grade = grade;
    }

    public int getSubmissionId() { return submissionId; }
    public void setSubmissionId(int submissionId) { this.submissionId = submissionId; }
    public int getAssignmentId() { return assignmentId; }
    public void setAssignment(int assignmentId) { this.assignmentId = assignmentId; }
    public int getStudentId() { return studentId; }
    public void setStudent(int studentId) { this.studentId = studentId; }
    public String getSubmissionDate() { return submissionDate; }
    public void setSubmissionDate(String submissionDate) { this.submissionDate = submissionDate; }
    public String getFilePath(){ return filePath; }
    public void setFilePath(String filePath){ this.filePath = filePath; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }
}
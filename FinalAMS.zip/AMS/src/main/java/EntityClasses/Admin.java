package EntityClasses;

public abstract class Admin extends User {
    public Admin(int userId, String username, String password, String email) {
        super(userId, username, password, email);
    }
}
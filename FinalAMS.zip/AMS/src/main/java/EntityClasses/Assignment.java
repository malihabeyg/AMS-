package EntityClasses;

public class Assignment {
    private int assignmentId;
    private int courseId;
    private String title;
    private String description;
    private String deadline;
    private String filePath;

    public Assignment(int assignmentId, int courseId, String title, String description, String deadline, String filePath) {
        this.assignmentId = assignmentId;
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.courseId = courseId;
        this.filePath = filePath;
    }

    public int getAssignmentId() { return assignmentId; }
    public void setAssignmentId(int assignmentId) { this.assignmentId = assignmentId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
    public int getCourseId() { return courseId; }
    public void setCourseId(int course) { this.courseId = course; }
    public String getFilePath(){ return filePath; }
    public void setFilePath(String filePath){ this.filePath = filePath; }
}
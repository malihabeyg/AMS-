package EntityClasses;

import ManagementClasses.StudentManagement;
import java.sql.SQLException;
import java.util.List;

public abstract class Student extends User {
    private List<Course> registeredCourses;
    
    public Student(){}
    public Student(int userId, String username, String password, String email, List<Course> registeredCourses) {
        super(userId, username, password, email);
        this.registeredCourses = registeredCourses;
    }
    
    public List<Course> getRegisteredCourses() { return registeredCourses; }
    public void setRegisteredCourses(List<Course> registeredCourses) { this.registeredCourses = registeredCourses; }
    
    public abstract void addStudent(StudentManagement newStd) throws SQLException;
    public abstract void updateStudent(int userId, String newUsername, String newPassword, String newEmail) throws SQLException;
    public abstract void removeStudent(int studentId) throws SQLException;
    public abstract List<User> viewRegisteredStudents() throws SQLException;
    public abstract int getStudentIdByUserId(int userId) throws SQLException;
}

package ManagementClasses;

import EntityClasses.Course;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.DatabaseConnection;
import EntityClasses.Assignment;
import java.util.ArrayList;
import java.util.List;

public class CourseManagement {
    
    // Method to add a new Course
    public void addNewCourse(int courseID, String courseName, int teachId) throws SQLException {
        String query = "INSERT INTO Courses (courseId, coursename, teachId) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            // Set parameters for the SQL query
            preparedStatement.setInt(1, courseID);
            preparedStatement.setString(2, courseName);
            preparedStatement.setInt(3, teachId);
            // Execute the query
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error while adding the course: " + e.getMessage(), e);
        }
    }
    
    // Method to update an existing Course
    public boolean updateCourse(int courseID, String courseName, int teachID) throws SQLException {
        String checkCourseQuery = "SELECT COUNT(*) FROM Courses WHERE courseId = ?";
        String checkTeacherQuery = "SELECT COUNT(*) FROM Teacher WHERE teachId = ?";
        String updateQuery = "UPDATE Courses SET coursename = ?, teachId = ? WHERE courseId = ?";

        try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement checkCourseStmt = connection.prepareStatement(checkCourseQuery);
            PreparedStatement checkTeacherStmt = connection.prepareStatement(checkTeacherQuery);
            PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {

            checkCourseStmt.setInt(1, courseID);
            ResultSet courseResult = checkCourseStmt.executeQuery();
            courseResult.next();
            if (courseResult.getInt(1) == 0) {
                return false; // Course ID does not exist
            }
            checkTeacherStmt.setInt(1, teachID);
            ResultSet teacherResult = checkTeacherStmt.executeQuery();
            teacherResult.next();
            if (teacherResult.getInt(1) == 0) {
                return false; // Teacher ID does not exist
            }

            updateStmt.setString(1, courseName);
            updateStmt.setInt(2, teachID);
            updateStmt.setInt(3, courseID);
            int rowsUpdated = updateStmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            throw new SQLException("Error while updating the course: " + e.getMessage(), e);
        }
    }

    // Method to delete a course from CourseId
    public boolean removeCourse(int courseId) throws SQLException {
        String deleteStudentCoursesQuery = "DELETE FROM StudentCourses WHERE courseId = ?";
        String deleteAssignmentsQuery = "DELETE FROM Assignment WHERE courseId = ?";
        String deleteCoursesQuery = "DELETE FROM Courses WHERE courseId = ?";

        try (Connection connection = DatabaseConnection.getConnection()) {
            connection.setAutoCommit(false); // Start transaction

            try (PreparedStatement deleteStudentCoursesStmt = connection.prepareStatement(deleteStudentCoursesQuery);
                PreparedStatement deleteAssignmentsStmt = connection.prepareStatement(deleteAssignmentsQuery);
                PreparedStatement deleteCoursesStmt = connection.prepareStatement(deleteCoursesQuery)) {
                // Step 1: Remove from StudentCourses
                deleteStudentCoursesStmt.setInt(1, courseId);
                deleteStudentCoursesStmt.executeUpdate();
                // Step 2: Remove from Assignments
                deleteAssignmentsStmt.setInt(1, courseId);
                deleteAssignmentsStmt.executeUpdate();
                // Step 3: Remove from Courses
                deleteCoursesStmt.setInt(1, courseId);
                int rowsAffected = deleteCoursesStmt.executeUpdate();
                // If no rows were affected in the Courses table, rollback
                if (rowsAffected == 0) {
                    connection.rollback();
                    return false; // CourseId does not exist in the Courses table
                }
                // Commit transaction if all operations succeeded
                connection.commit();
                return true;
            } catch (SQLException e) {
                // Rollback on error
                connection.rollback();
                throw new SQLException("Error while removing the course: " + e.getMessage(), e);
            }
        }
    }


    // Method to get List of Courses Registered by student
    public List<Course> getRegisteredCourses(int studentId) throws Exception {
        List<Course> registeredCourses = new ArrayList<>();

        String query = "SELECT c.courseId, c.coursename, c.teachId " +
                       "FROM Courses c " +
                       "INNER JOIN StudentCourses sc ON c.courseId = sc.courseId " +
                       "WHERE sc.stdId = ?;";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int courseId = rs.getInt("courseId");
                String courseName = rs.getString("coursename");
                int teachId = rs.getInt("teachId");

                // Create a Course object and add it to the list
                Course course = new Course(courseId, courseName, teachId);
                registeredCourses.add(course);
            }
        } catch (Exception e) {
            System.out.println("\"Error fetching registered courses: \" + e.getMessage()");
        }
        return registeredCourses;
    }
    
    // Method to List Courses Taught by a Teacher
    public List<Course> getCoursesTeacher(int TeacherId) throws SQLException {
        List<Course> courses = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "SELECT * FROM Courses WHERE teachId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, TeacherId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int courseID = rs.getInt("courseId");
                String courseName = rs.getString("coursename");
                int tchID = rs.getInt("teachId");
                Course course = new Course(courseID, courseName,tchID);
                courses.add(course);
            }
        } finally {
            DatabaseConnection.closeConnection();
        }
        return courses;
    }
    
    // Method to get list of assignments uploaded for a courses.
    public List<Assignment> getAssignmentsForCourse(Course course) throws SQLException {
        List<Assignment> assignments = new ArrayList<>();
        
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "SELECT * FROM Assignment WHERE courseID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, course.getCourseId());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int assignmentID = Integer.parseInt(rs.getString("assId"));
                String title = rs.getString("title");
                String description = rs.getString("description");
                String dueDate = rs.getString("duedate");
                String filePath = rs.getString("filePath");
                Assignment assignment = new Assignment(assignmentID, course.getCourseId(), title, description, dueDate,filePath);
                assignments.add(assignment);
            }
        } finally {
            DatabaseConnection.closeConnection();
        }
        return assignments;
    }
}

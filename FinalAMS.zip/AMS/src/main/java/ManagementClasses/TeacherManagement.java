package ManagementClasses;

import EntityClasses.Teacher;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.DatabaseConnection;
import EntityClasses.Course;
import EntityClasses.User;
import java.util.ArrayList;
import java.util.List;

public class TeacherManagement extends Teacher {
    public TeacherManagement(){}
    public TeacherManagement(int userId, String username, String password, String email, List<Course> assignedCourses) {
        super(userId, username, password, email, assignedCourses);
    }
    
    // Method to add a new Teacher
    @Override
    public void addTeacher(TeacherManagement newTeacher) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Step 1: Add the user to the Users table
            String userQuery = "INSERT INTO Users (username, password, email, role) VALUES (?, ?, ?, ?)";
            PreparedStatement userStmt = connection.prepareStatement(userQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, newTeacher.getUsername());
            userStmt.setString(2, newTeacher.getPassword());
            userStmt.setString(3, newTeacher.getEmail());
            userStmt.setString(4, "Teacher");
            userStmt.executeUpdate();

            // Retrieve the generated userId
            ResultSet generatedKeys = userStmt.getGeneratedKeys();
            if (!generatedKeys.next()) { throw new SQLException("Failed to insert user into Users table, no ID obtained."); }
            int userId = generatedKeys.getInt(1);

            // Step 2: Add the teacher to the Teachers table
            String teacherQuery = "INSERT INTO Teacher (username, password, userId) VALUES (?, ?, ?)";
            PreparedStatement teacherStmt = connection.prepareStatement(teacherQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            teacherStmt.setString(1, newTeacher.getUsername());
            teacherStmt.setString(2, newTeacher.getPassword());
            teacherStmt.setInt(3, userId);
            teacherStmt.executeUpdate();
            // Retrieve the auto-generated teacherId
            ResultSet teacherKeys = teacherStmt.getGeneratedKeys();
            if (!teacherKeys.next()) { throw new SQLException("Failed to insert teacher into Teachers table, no ID obtained."); }
            int teacherId = teacherKeys.getInt(1);

            // Step 3: Update the teachId in the Courses table for the assigned courses
            String updateCourseQuery = "UPDATE Courses SET teachId = ? WHERE courseId = ?";
            PreparedStatement updateCourseStmt = connection.prepareStatement(updateCourseQuery);
            // Loop through the assigned courses and update the teachId
            for (Course course : newTeacher.getAssignedCourses()) {
                updateCourseStmt.setInt(1, teacherId); // Assign teacherId
                updateCourseStmt.setInt(2, course.getCourseId()); // Match courseId
                updateCourseStmt.addBatch();
            }
            // Execute the batch update
            updateCourseStmt.executeBatch();
            // Commit the transaction
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Error while adding teacher: " + e.getMessage());
            throw e; 
        } finally {
            if (connection != null) { connection.close(); }
        }
    }

    // Method to update username, password and email of teacher
    @Override
    public void updateTeacher(int userId, String newUsername, String newPassword, String newEmail) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Step 1: Update the Users table
            String userUpdateQuery = "UPDATE Users SET username = ?, password = ?, email = ? WHERE userId = ?";
            PreparedStatement userStmt = connection.prepareStatement(userUpdateQuery);
            userStmt.setString(1, newUsername);
            userStmt.setString(2, newPassword);
            userStmt.setString(3, newEmail);
            userStmt.setInt(4, userId);
            userStmt.executeUpdate();
            // Step 2: Update the Teachers table
            String teacherUpdateQuery = "UPDATE Teacher SET username = ?, password = ? WHERE userId = ?";
            PreparedStatement teacherStmt = connection.prepareStatement(teacherUpdateQuery);
            teacherStmt.setString(1, newUsername);
            teacherStmt.setString(2, newPassword);
            teacherStmt.setInt(3, userId);
            teacherStmt.executeUpdate();
            // Commit the transaction
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Error while updating teacher: " + e.getMessage());
            throw e;
        } finally {
        if (connection != null) { connection.close(); }
        }
    }

    @Override
    public void removeTeacher(int teacherId) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Step 1: Retrieve the userId for the teacher
            String getUserIdQuery = "SELECT userId FROM Teacher WHERE teachId = ?";
            PreparedStatement getUserIdStmt = connection.prepareStatement(getUserIdQuery);
            getUserIdStmt.setInt(1, teacherId);
            ResultSet rs = getUserIdStmt.executeQuery();
            int userId = -1;
            if (rs.next()) { userId = rs.getInt("userId"); } else {
                throw new SQLException("Teacher not found for the provided teacherId: " + teacherId);
            }
            
            // Step 2: Unassign courses taught by the teacher in the Courses table
            String unassignCoursesQuery = "UPDATE Courses SET teachId = NULL WHERE teachId = ?";
            PreparedStatement unassignCoursesStmt = connection.prepareStatement(unassignCoursesQuery);
            unassignCoursesStmt.setInt(1, teacherId);
            unassignCoursesStmt.executeUpdate();

            // Step 3: Delete teacher record from Teachers table
            String deleteTeacherQuery = "DELETE FROM Teacher WHERE teachId = ?";
            PreparedStatement deleteTeacherStmt = connection.prepareStatement(deleteTeacherQuery);
            deleteTeacherStmt.setInt(1, teacherId);
            deleteTeacherStmt.executeUpdate();

            // Step 4: Delete user record from Users table
            String deleteUserQuery = "DELETE FROM Users WHERE userId = ?";
            PreparedStatement deleteUserStmt = connection.prepareStatement(deleteUserQuery);
            deleteUserStmt.setInt(1, userId);
            deleteUserStmt.executeUpdate();
            connection.commit();
            System.out.println("Teacher removed successfully.");
        } catch (SQLException e) {
            throw new SQLException("Error while removing teacher: " + e.getMessage(), e);
        } finally {
            if (connection != null) { connection.close(); }
        }
    }


    // Method to view all registered teachers
    @Override
    public List<User> getTeachers() throws SQLException {
        List<User> teachers = new ArrayList<>();
        String query = "SELECT userId, username, password, email FROM Users WHERE role = 'Teacher'";
        try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User teacher = new User(
                    rs.getInt("userId"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("email")
                );
                teachers.add(teacher);
            }
        }
        return teachers;
    }


    // Method to get StudentId through User Id
    @Override
    public int getTeacherIdByUserId(int userId) throws SQLException {
        String query = "SELECT teachId FROM Teacher WHERE userId = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("teachId");
            }
        }
        return -1;
    }
}

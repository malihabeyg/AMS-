package ManagementClasses;

import Database.DatabaseConnection;
import EntityClasses.Assignment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AssignmentManagement {
    
    // Method to add a new Assignment task
    public void addAssignment(Assignment assignment) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO Assignment (assId, title, description, duedate, filepath, courseId) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, assignment.getAssignmentId());
            stmt.setString(2, assignment.getTitle());
            stmt.setString(3, assignment.getDescription());
            stmt.setString(4, assignment.getDeadline());
            stmt.setString(5, assignment.getFilePath());
            stmt.setInt(6, assignment.getCourseId());
            stmt.executeUpdate();
        } finally {
            DatabaseConnection.closeConnection();
        }
    }
    
    // Method to delete an Assignment uploaded by Teacher.
    public void deleteAssignment(int assignmentId) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()){
            String query = "DELETE FROM Assignment WHERE assId = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, assignmentId);
            stmt.executeUpdate();
        } finally {
            DatabaseConnection.closeConnection();
        }
    }
}

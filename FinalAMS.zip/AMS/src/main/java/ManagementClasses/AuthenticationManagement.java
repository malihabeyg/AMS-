package ManagementClasses;

import EntityClasses.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.DatabaseConnection;
import EntityClasses.Course;
import java.util.ArrayList;
import java.util.List;

public class AuthenticationManagement {
    // Method to authenticate a user
    public static User login(String username, String password, String role, List<Course> assignedCourses) throws SQLException {
    Connection conn = DatabaseConnection.getConnection();
    String query = "SELECT userId, username, password, email FROM Users WHERE username = ? AND password = ? AND role = ?;";
    PreparedStatement prepStat = conn.prepareStatement(query);
    prepStat.setString(1, username);
    prepStat.setString(2, password);
    prepStat.setString(3, role);
    ResultSet rs = prepStat.executeQuery();

    if (rs.next()) {
        int userId = rs.getInt("userId");
        String email = rs.getString("email");

        switch (role.toLowerCase()) {
            case "student":
                StudentManagement stdManag = new StudentManagement();
                int stdId = stdManag.getStudentIdByUserId(userId);
                List<Course> registeredCourses = getCourses(stdId);
                for(Course red : registeredCourses){
                    System.out.println(red.getCourseName());
                }
                System.out.println("");
                return new StudentManagement(userId, username, password, email, registeredCourses);

            case "teacher":
                TeacherManagement teachManag = new TeacherManagement();
                int teachId = teachManag.getTeacherIdByUserId(userId);
                CourseManagement courseManag = new CourseManagement();
                List<Course> assignedCourse = courseManag.getCoursesTeacher(teachId);
                for(Course red : assignedCourse){
                    System.out.println(red.getCourseName());
                }
                System.out.println("");
                return new TeacherManagement(userId, username, password, email, assignedCourses);

            case "admin":
                return new AdminManagement(userId, username, password, email);

            default:
                System.out.println("Invalid role.");
                return null;
        }
    } else {
        System.out.println("Invalid username, password, or role.");
    }
    return null;
}


    public static void logout(User currentUser) {
        currentUser = null;
        System.out.println("User logged out successfully.");
    }
    
    public static List<Course> getCourses(int stdId) {
        List<Course> courses = new ArrayList<>();
        try {
            CourseManagement coursemanag = new CourseManagement();
            courses = coursemanag.getRegisteredCourses(stdId);
        } catch (Exception e) {
            System.out.println("Error getting student courses: " + e.getMessage());
        }
        return courses;
    }
}
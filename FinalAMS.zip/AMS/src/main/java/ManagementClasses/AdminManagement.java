package ManagementClasses;

import EntityClasses.Admin;

public class AdminManagement extends Admin{
    public AdminManagement(int userId, String username, String password, String email) {
        super(userId, username, password, email);
    }       
}

package ManagementClasses;

import EntityClasses.Submission;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.DatabaseConnection;
import EntityClasses.Grade;
import java.util.ArrayList;
import java.util.List;

public class SubmissionManagement {
    
    // Method to submit an assignment
    public void submitAssignment(Submission submission) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "INSERT INTO Submissions (assId, stdId, subDate, subfilepath) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, submission.getAssignmentId());
            stmt.setInt(2, submission.getStudentId());
            stmt.setString(3, submission.getSubmissionDate());
            stmt.setString(4, submission.getFilePath());
            stmt.executeUpdate();
        } finally {
            DatabaseConnection.closeConnection();
        }
    }
    
    // Method to delete a Submission  
    public void deleteSubmission(int submissionId) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "DELETE FROM Submissions WHERE subId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, submissionId);
            stmt.executeUpdate();
        } finally {
            DatabaseConnection.closeConnection();
        }
    }
    
    // Method to fetch grade of a Submission
    public Grade getGrade(int submissionId) throws SQLException {
        Grade grade = null;
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "SELECT * FROM Submissions WHERE subId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, submissionId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String gradeValue = rs.getString("grade");
                grade = new Grade(submissionId, gradeValue);
            }
        } finally {
            DatabaseConnection.closeConnection();
        }
        return grade;
    }

    // Method to grade a submission by  student
    public void gradeSubmission(int submissionId, String grade) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()){
            String query = "UPDATE Submissions SET grade = ? WHERE subId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, grade);
            stmt.setInt(2, submissionId);
            stmt.executeUpdate();
        }finally{
            DatabaseConnection.closeConnection();
        }
    }

    // Method to fetch submissions by a specific student
    public List<Submission> getSubmissionsByStudent(int studentId) throws SQLException {
        List<Submission> submissions = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Submissions sub " + "WHERE sub.stdId = ?;";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            System.out.println("Submissions for Student ID: " + studentId);
            while (rs.next()) {
               int submissionID = Integer.parseInt(rs.getString("subID"));
               int assignmentID = Integer.parseInt(rs.getString("assID"));
               String submissionDate = rs.getString("subDate");
               String filePath = rs.getString("subfilepath");
               String grade=rs.getString("grade");
               Submission submission = new Submission(submissionID, assignmentID, studentId, submissionDate, filePath,grade);
               submissions.add(submission);
            }
        } catch (SQLException e) {
            System.out.println("Could'nt fetch submissions for student" + e.getMessage());
        }finally{
            DatabaseConnection.closeConnection();
        }
        return submissions;
    }
    
    // Method to show submissions of stuents to teacher
    public List<Submission> getStudentSubmissions(int assignmentId) throws SQLException {
        List<Submission> submissions = new ArrayList<>();
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Submissions WHERE assId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int submissionId = rs.getInt("subId");
                int studentID = rs.getInt("stdId");
                String submissionDate = rs.getString("subDate");
                String grade = rs.getString("grade");
                String filePath = rs.getString("subfilepath");
                Submission submission = new Submission(submissionId, assignmentId , studentID, submissionDate, filePath, grade);
                submissions.add(submission);
            }
        } catch (SQLException e) {
            System.out.println("Could'nt fetch submissions for assignment" + e.getMessage());
        }finally{
            DatabaseConnection.closeConnection();
        }
        return submissions;
    }
}


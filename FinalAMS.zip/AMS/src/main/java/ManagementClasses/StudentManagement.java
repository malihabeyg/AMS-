package ManagementClasses;

import EntityClasses.Student;
import EntityClasses.Course;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.DatabaseConnection;
import EntityClasses.User;
import java.util.ArrayList;
import java.util.List;

public class StudentManagement extends Student{
    public StudentManagement(){}
    public StudentManagement(int userId, String username, String password, String email, List<Course> registeredCourses) {
        super(userId, username, password, email, registeredCourses);
    }
    
    // Method to add a new Student
    @Override
    public void addStudent(StudentManagement newStd) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false); // Start transaction
            // Step 1: Add the user to the Users table
            String userQuery = "INSERT INTO Users (username, password, email, role) VALUES (?, ?, ?, ?)";
            PreparedStatement userStmt = connection.prepareStatement(userQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, newStd.getUsername());
            userStmt.setString(2, newStd.getPassword());
            userStmt.setString(3, newStd.getEmail());
            userStmt.setString(4, "Student");
            userStmt.executeUpdate();
            // Retrieve the generated userId
            ResultSet generatedKeys = userStmt.getGeneratedKeys();
            if (!generatedKeys.next()) { throw new SQLException("Failed to insert user into Users table, no ID obtained."); }
            int userId = generatedKeys.getInt(1);

            // Step 2: Add the student to the Students table
            String studentQuery = "INSERT INTO Students (username, password, userId) VALUES (?, ?, ?)";
            PreparedStatement studentStmt = connection.prepareStatement(studentQuery);
            studentStmt.setString(1, newStd.getUsername());
            studentStmt.setString(2, newStd.getPassword());
            studentStmt.setInt(3, userId);
            studentStmt.executeUpdate();
            // Retrieve the auto-generated studentId
            ResultSet studentKeys = studentStmt.getGeneratedKeys();
            if (!studentKeys.next()) { throw new SQLException("Failed to insert student into Students table, no ID obtained."); }
            int stdId = studentKeys.getInt(1); // Auto-incremented studentId

            // Step 3: Insert the selected courses into the StudentCourses table
            String studentCoursesQuery = "INSERT INTO StudentCourses (courseId, stdId, coursename) VALUES (?, ?, ?)";
            PreparedStatement studentCoursesStmt = connection.prepareStatement(studentCoursesQuery);
            // Insert each selected course for the student
            for (Course course : newStd.getRegisteredCourses()) {
                studentCoursesStmt.setInt(1, course.getCourseId());
                studentCoursesStmt.setInt(2, stdId); 
                studentCoursesStmt.setString(3, course.getCourseName());
                studentCoursesStmt.addBatch(); // Add to batch for efficient insertion
            }
            // Execute the batch insert
            studentCoursesStmt.executeBatch();
            // Commit transaction
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Error while adding student: " + e.getMessage());
        } finally {
            if (connection != null) { DatabaseConnection.closeConnection(); }
        }
    }

    // Method to update username, password and email
    public void updateStudent(int userId, String newUsername, String newPassword, String newEmail) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Step 1: Update the Users table
            String userUpdateQuery = "UPDATE Users SET username = ?, password = ?, email = ? WHERE userId = ?";
            PreparedStatement userStmt = connection.prepareStatement(userUpdateQuery);
            userStmt.setString(1, newUsername);
            userStmt.setString(2, newPassword);
            userStmt.setString(3, newEmail);
            userStmt.setInt(4, userId);
            userStmt.executeUpdate();

            // Step 2: Update the Students table
            String studentUpdateQuery = "UPDATE Students SET username = ?, password = ? WHERE userId = ?";
            PreparedStatement studentStmt = connection.prepareStatement(studentUpdateQuery);
            studentStmt.setString(1, newUsername);
            studentStmt.setString(2, newPassword);
            studentStmt.setInt(3, userId);
            studentStmt.executeUpdate();
            // Commit the transaction
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Error while updating student: " + e.getMessage());
            throw e;
        } finally {
            if (connection != null) { connection.close(); }
        }
    }

    // Method to remove student by their id
    @Override
    public void removeStudent(int studentId) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);
            
            // Step 1: Retrieve the userId for the teacher
            String getUserIdQuery = "SELECT userId FROM Students WHERE stdId = ?";
            PreparedStatement getUserIdStmt = connection.prepareStatement(getUserIdQuery);
            getUserIdStmt.setInt(1, studentId);
            ResultSet rs = getUserIdStmt.executeQuery();
            int userId = -1;
            if (rs.next()) { userId = rs.getInt("userId"); } else {
                throw new SQLException("Student not found for the provided studentId: " + studentId);
            }

            // Step 1: Delete student courses from StudentCourses table
            String deleteStudentCoursesQuery = "DELETE FROM StudentCourses WHERE stdId = ?";
            PreparedStatement deleteStudentCoursesStmt = connection.prepareStatement(deleteStudentCoursesQuery);
            deleteStudentCoursesStmt.setInt(1, studentId);
            deleteStudentCoursesStmt.executeUpdate();
            // Step 2: Delete student record from Students table
            String deleteStudentQuery = "DELETE FROM Students WHERE stdId = ?";
            PreparedStatement deleteStudentStmt = connection.prepareStatement(deleteStudentQuery);
            deleteStudentStmt.setInt(1, studentId);
            deleteStudentStmt.executeUpdate();
            // Step 3: Delete user record from Users table
            String deleteUserQuery = "DELETE FROM Users WHERE userId = ?";
            PreparedStatement deleteUserStmt = connection.prepareStatement(deleteUserQuery);
            deleteUserStmt.setInt(1, userId);
            deleteUserStmt.executeUpdate();
            connection.commit();
            System.out.println("Student removed successfully.");
        } catch (SQLException e) {
            throw new SQLException("Error while removing student: " + e.getMessage());
        } finally {
            if (connection != null) { connection.close(); }
        }
    }
    
    // Method to view all registered students
    @Override
    public List<User> viewRegisteredStudents() throws SQLException {
        List<User> students = new ArrayList<>();
        String query = "SELECT userId, username, password, email FROM Users WHERE role = 'Student'";
        try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User student = new User(
                    rs.getInt("userId"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("email")
                );
                students.add(student);
            }
        }
        return students;
    }
    
    // Method to get StudentId through User Id
    @Override
    public int getStudentIdByUserId(int userId) throws SQLException {
        String query = "SELECT stdId FROM Students WHERE userId = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("stdId");
            }
        }
        return -1;
    }
}
